

<?php $__env->startSection('title', 'New Product — Sports Warehouse'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-6 md:py-10">
    <div class="container-960">
        <div class="pill-heading mb-5"><h1>New Product</h1></div>

        <div class="contact-card max-w-[640px]">
            <form action="<?php echo e(route('admin.items.store')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <label for="itemName" class="contact-label">Name</label>
                <input type="text" id="itemName" name="itemName" value="<?php echo e(old('itemName')); ?>" class="contact-input">
                <?php $__errorArgs = ['itemName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1 mb-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label for="categoryId" class="contact-label mt-3">Category</label>
                <select id="categoryId" name="categoryId" class="contact-input">
                    <option value="">-- Select a category --</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->categoryId); ?>" <?php if(old('categoryId') == $category->categoryId): echo 'selected'; endif; ?>>
                            <?php echo e($category->categoryName); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['categoryId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1 mb-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="flex gap-4">
                    <div class="flex-1">
                        <label for="price" class="contact-label mt-3">Price ($)</label>
                        <input type="number" step="0.01" min="0" id="price" name="price" value="<?php echo e(old('price', 0)); ?>" class="contact-input">
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1 mb-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="flex-1">
                        <label for="salePrice" class="contact-label mt-3">Sale price ($) — optional</label>
                        <input type="number" step="0.01" min="0" id="salePrice" name="salePrice" value="<?php echo e(old('salePrice')); ?>" class="contact-input">
                        <?php $__errorArgs = ['salePrice'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1 mb-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <label for="description" class="contact-label mt-3">Description</label>
                <textarea id="description" name="description" rows="4" class="contact-input resize-y"><?php echo e(old('description')); ?></textarea>

                <label class="contact-label mt-3">Photo</label>
                <img id="imagePreview" src="<?php echo e(asset('assets/placeholder-image.png')); ?>" class="w-28 h-28 object-contain border border-gray-300 rounded mb-2 bg-white">
                <button type="button" id="removePhotoBtn" class="mt-2 text-sm text-red-600 hover:underline">Clear selection</button>
                <input type="file" name="photo" id="imageInput" accept="image/*" class="block w-full text-sm text-sw-grey border border-gray-300 rounded cursor-pointer
                 file:mr-4 file:py-2.5 file:px-4 file:border-0 file:cursor-pointer
                 file:bg-sw-teal file:text-white file:font-semibold hover:file:bg-sw-orange">
                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1 mb-2"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label class="inline-flex items-center mt-3">
                    <input type="checkbox" name="featured" value="1" <?php if(old('featured')): echo 'checked'; endif; ?> class="mr-2"> Featured on homepage
                </label>

                <div class="mt-5">
                    <button type="submit" class="contact-submit">Create Product</button>
                    <a href="<?php echo e(route('admin.items.index')); ?>" class="ml-3 text-sw-grey hover:underline">Cancel</a>
                </div>

<script>
                document.addEventListener('DOMContentLoaded', function () {
                const input = document.getElementById('imageInput');
                const preview = document.getElementById('imagePreview');
                const removeBtn = document.getElementById('removePhotoBtn');
                const placeholder = "<?php echo e(asset('assets/placeholder-image.png')); ?>";

                 input.addEventListener('change', function () {
                 if (this.files[0]) preview.src = URL.createObjectURL(this.files[0]);
             });

                removeBtn.addEventListener('click', function () {
                input.value = '';            // clear the chosen file
                preview.src = placeholder;   // back to placeholder
             });
    });
</script>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\info\sports-warehouse\resources\views/admin/items/create.blade.php ENDPATH**/ ?>