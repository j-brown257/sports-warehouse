

<?php $__env->startSection('title', $item->itemName . ' — Sports Warehouse'); ?>

<?php $__env->startSection('content'); ?>

<section class="py-6 md:py-10">
    <div class="container-960">

        
        <?php if($item->category): ?>
            <nav class="text-sm text-sw-grey mb-4" aria-label="Breadcrumb">
                <a href="<?php echo e(route('home')); ?>" class="hover:text-sw-blue hover:underline">Home</a>
                <span class="mx-2">›</span>
                <a href="<?php echo e(route('categories.show', $item->category->slug)); ?>" class="hover:text-sw-blue hover:underline"><?php echo e($item->category->categoryName); ?></a>
                <span class="mx-2">›</span>
                <span class="text-gray-800"><?php echo e($item->itemName); ?></span>
            </nav>
        <?php endif; ?>

        
        <div class="bg-white border border-gray-200 rounded-lg p-5 md:p-8">
            <div class="md:flex md:gap-8 md:items-start">

                
                <div class="md:w-1/2 mb-6 md:mb-0">
                    <img src="<?php echo e($item->photo_url); ?>"
                         alt="<?php echo e($item->itemName); ?>"
                         class="w-full max-w-[400px] h-auto mx-auto">
                </div>

                
                <div class="md:w-1/2">
                    <h1 class="text-2xl md:text-3xl font-bold text-gray-800 mb-3"><?php echo e($item->itemName); ?></h1>

                    
                    <div class="mb-5">
                        <?php if(!is_null($item->salePrice) && $item->salePrice > 0): ?>
                            <span class="text-sw-orange text-3xl font-bold">$<?php echo e(number_format($item->salePrice, 2)); ?></span>
                            <span class="line-through text-gray-400 text-lg ml-2">$<?php echo e(number_format($item->price, 2)); ?></span>
                            <span class="block text-sm text-sw-orange font-semibold mt-1">On sale!</span>
                        <?php else: ?>
                            <span class="text-3xl font-bold text-gray-800">$<?php echo e(number_format($item->price, 2)); ?></span>
                        <?php endif; ?>
                    </div>

                    
                    <?php if($item->description): ?>
                        <h2 class="text-lg font-semibold text-gray-800 mb-2">Description</h2>
                        <p class="text-base text-sw-grey leading-relaxed"><?php echo e($item->description); ?></p>
                    <?php endif; ?>
                    <form action="<?php echo e(route('cart.add', $item->itemId)); ?>" method="POST" class="mt-6 flex items-end gap-3">
                    <?php echo csrf_field(); ?>
                        <div>
                        <label for="qty" class="block mb-1 text-sm text-sw-grey">Quantity</label>
                        <input type="number" id="qty" name="qty" value="1" min="1" class="w-20 px-3 py-2 border border-gray-300 rounded text-sw-grey bg-white focus:outline-2 focus:outline-sw-blue focus:border-sw-blue">
                        </div>
                        <button type="submit" class="h-[42px] px-6 bg-sw-orange text-white font-semibold rounded hover:bg-sw-teal transition-colors">
                        <i class="fas fa-shopping-cart mr-2"></i>Add to Cart    
                        </button>
                    </form>
                </div>
            </div>
        </div>

        
        <?php if($item->category): ?>
            <div class="mt-6 text-center">
                <a href="<?php echo e(route('categories.show', $item->category->slug)); ?>" class="text-sw-blue hover:underline">
                    ← Back to <?php echo e($item->category->categoryName); ?>

                </a>
            </div>
        <?php endif; ?>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\info\sports-warehouse\resources\views/item.blade.php ENDPATH**/ ?>