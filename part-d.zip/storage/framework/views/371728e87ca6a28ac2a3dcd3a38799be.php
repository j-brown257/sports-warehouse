

<?php $__env->startSection('title', ($q !== '' ? 'Search: ' . $q : 'Search') . ' — Sports Warehouse'); ?>

<?php $__env->startSection('content'); ?>

<section class="py-6 md:py-10">
    <div class="container-960">

        
        <div class="pill-heading mb-5">
            <h2>
                <?php if($q !== ''): ?>
                    Search results for "<?php echo e($q); ?>"
                <?php else: ?>
                    Search products
                <?php endif; ?>
            </h2>
        </div>

        <?php if($q === ''): ?>

            
            <div class="text-center py-12 text-sw-grey">
                <p class="text-lg">Use the search bar at the top of the page to find products by name.</p>
                <p class="mt-2">
                    Or <a href="<?php echo e(route('products.index')); ?>" class="text-sw-blue hover:underline">browse all products</a>.
                </p>
            </div>

        <?php elseif($items->isEmpty()): ?>

            
            <div class="text-center py-12 text-sw-grey">
                <p class="text-lg font-semibold text-gray-800">No results to display.</p>
                <p class="mt-2">We couldn't find any products matching <strong>"<?php echo e($q); ?>"</strong>.</p>
                <p class="mt-2">
                    Try a different search term, or
                    <a href="<?php echo e(route('products.index')); ?>" class="text-sw-blue hover:underline">browse all products</a>.
                </p>
            </div>

        <?php else: ?>

            
            <p class="text-sw-grey mb-5">
                Found <?php echo e($items->count()); ?> <?php echo e($items->count() === 1 ? 'product' : 'products'); ?> matching <strong>"<?php echo e($q); ?>"</strong>.
            </p>

            <div class="grid grid-cols-2 md:grid-cols-5 gap-4 md:gap-5">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('items.show', $item->slug)); ?>" class="product-card block no-underline hover:shadow-md transition-shadow">
                        <img src="/assets/<?php echo e($item->photo); ?>" alt="<?php echo e($item->itemName); ?>"
                             class="max-w-[100px] w-full h-auto mx-auto mb-2.5">

                        <p class="m-0">
                            <?php if(!is_null($item->salePrice) && $item->salePrice > 0): ?>
                                <span class="text-sw-orange text-lg font-bold">$<?php echo e(number_format($item->salePrice, 2)); ?></span>
                                <span class="line-through text-gray-400 text-sm ml-1">$<?php echo e(number_format($item->price, 2)); ?></span>
                            <?php else: ?>
                                <span class="text-lg font-bold text-gray-800">$<?php echo e(number_format($item->price, 2)); ?></span>
                            <?php endif; ?>
                        </p>

                        <p class="text-sm text-sw-product mt-1"><?php echo e($item->itemName); ?></p>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        <?php endif; ?>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\info\sports-warehouse\resources\views/search.blade.php ENDPATH**/ ?>