

<?php $__env->startSection('title', 'Update Password — Sports Warehouse'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-6 md:py-10">
    <div class="container-960">
        <div class="pill-heading mb-5"><h1>Update Password</h1></div>

        <?php if(session('status')): ?>
            <div class="alert-success"><?php echo e(session('status')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert-error">
                <ul class="list-disc list-inside m-0 p-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="contact-card max-w-[420px]">
            <form action="<?php echo e(route('account.password.update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <fieldset class="contact-fieldset">
                    <legend class="contact-legend">Change your password</legend>
                    <div class="mb-4">
                        <label for="current_password" class="contact-label">Current password</label>
                        <input type="password" id="current_password" name="current_password" required class="contact-input">
                    </div>
                    <div class="mb-4">
                        <label for="new_password" class="contact-label">New password</label>
                        <input type="password" id="new_password" name="new_password" required class="contact-input">
                    </div>
                    <div class="mb-4">
                        <label for="new_password_confirmation" class="contact-label">Confirm new password</label>
                        <input type="password" id="new_password_confirmation" name="new_password_confirmation" required class="contact-input">
                    </div>
                    <button type="submit" class="contact-submit">Update password</button>
                </fieldset>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\info\sports-warehouse\resources\views/auth/password.blade.php ENDPATH**/ ?>