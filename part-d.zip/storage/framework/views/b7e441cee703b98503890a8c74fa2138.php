

<?php $__env->startSection('title', 'Manage Categories — Sports Warehouse'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-6 md:py-10">
    <div class="container-960">
        <?php echo $__env->make('admin._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="pill-heading mb-5"><h1>Categories</h1></div>

        <?php if(session('success')): ?><div class="alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
        <?php if(session('error')): ?><div class="alert-error"><?php echo e(session('error')); ?></div><?php endif; ?>

        <div class="mb-4">
            <a href="<?php echo e(route('admin.categories.create')); ?>"
               class="inline-block px-5 py-2.5 bg-sw-blue text-white font-semibold rounded hover:bg-sw-teal transition-colors">+ New Category</a>
        </div>

        <div class="bg-white border border-gray-300 rounded-lg overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="border-b-2 border-gray-200 text-sw-grey text-sm">
                        <th class="p-3">ID</th>
                        <th class="p-3">Name</th>
                        <th class="p-3"># Items</th>
                        <th class="p-3 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-b border-gray-100">
                            <td class="p-3"><?php echo e($category->categoryId); ?></td>
                            <td class="p-3"><?php echo e($category->categoryName); ?></td>
                            <td class="p-3"><?php echo e($category->items()->count()); ?></td>
                            <td class="p-3 text-right whitespace-nowrap">
                                <a href="<?php echo e(route('admin.categories.edit', $category)); ?>" class="text-sw-blue hover:underline mr-4">Edit</a>
                                <form action="<?php echo e(route('admin.categories.destroy', $category)); ?>" method="POST" class="inline" onsubmit="return confirm('Delete this category?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:underline">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="p-3 text-sw-grey">No categories yet.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\info\sports-warehouse\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>