

<?php $__env->startSection('title', 'New Category — Sports Warehouse'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-6 md:py-10">
    <div class="container-960">
        <div class="pill-heading mb-5"><h1>Create a New Category</h1></div>

        <div class="contact-card max-w-[480px]">
            <form action="<?php echo e(route('admin.categories.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <label for="categoryName" class="contact-label">Name</label>
                <input type="text" id="categoryName" name="categoryName" value="<?php echo e(old('categoryName')); ?>" class="contact-input">
                <?php $__errorArgs = ['categoryName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="mt-4">
                    <button type="submit" class="contact-submit">Create Category</button>
                    <a href="<?php echo e(route('admin.categories.index')); ?>" class="ml-3 text-sw-grey hover:underline">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\info\sports-warehouse\resources\views/admin/categories/create.blade.php ENDPATH**/ ?>