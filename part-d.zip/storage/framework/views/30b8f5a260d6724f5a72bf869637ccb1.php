

<?php $__env->startSection('title', $category->categoryName . ' — Sports Warehouse'); ?>

<?php $__env->startSection('content'); ?>

<section class="py-6 md:py-10">
    <div class="container-960">

        
        <div class="pill-heading mb-5">
            <h2><?php echo e($category->categoryName); ?></h2>
        </div>

        <?php if($items->isEmpty()): ?>

            
            <div class="text-center py-12 text-sw-grey">
                <p class="text-lg">There are no products in this category yet.</p>
                <p class="mt-2">
                    Please check back soon, or
                    <a href="<?php echo e(route('home')); ?>" class="text-sw-blue hover:underline">browse our home page</a>.
                </p>
            </div>

        <?php else: ?>

            
            <div class="grid grid-cols-2 md:grid-cols-5 gap-4 md:gap-5">
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('items.show', $item->slug)); ?>" class="product-card block no-underline hover:shadow-md transition-shadow">
                        <img src="<?php echo e($item->photo_url); ?>"
                             alt="<?php echo e($item->itemName); ?>"
                             class="max-w-[100px] w-full h-auto mx-auto mb-2.5">

                        <p class="m-0">
                            <?php if(!is_null($item->salePrice) && $item->salePrice > 0): ?>
                                <span class="text-sw-orange text-lg font-bold">$<?php echo e(number_format($item->salePrice, 2)); ?></span>
                                <span class="line-through text-gray-400 text-sm ml-1">$<?php echo e(number_format($item->price, 2)); ?></span>
                            <?php else: ?>
                                <span class="text-lg font-bold text-gray-800">$<?php echo e(number_format($item->price, 2)); ?></span>
                            <?php endif; ?>
                        </p>

                        <p class="text-sm text-sw-product mt-1"><?php echo e($item->itemName); ?></p>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        <?php endif; ?>

    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\info\sports-warehouse\resources\views/category.blade.php ENDPATH**/ ?>