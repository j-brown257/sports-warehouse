

<?php $__env->startSection('title', 'Sports Warehouse — Home'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="sr-only">Sports Warehouse — Home</h1>


<div class="hidden md:block">
    <div class="container-960 py-2">
        <img src="<?php echo e(asset('assets/banner.png')); ?>" alt="Sports Warehouse banner" class="w-full h-auto block">
    </div>
</div>


<section class="py-6 md:py-10">
    <div class="container-960">

        <div class="pill-heading mb-5">
            <h2>Featured Products</h2>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-5 gap-4 md:gap-5">
            <?php $__currentLoopData = $featuredItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('items.show', $item->slug)); ?>" class="product-card block no-underline hover:shadow-md transition-shadow">
                    <img src="<?php echo e($item->photo_url); ?>"
                         alt="<?php echo e($item->itemName); ?>"
                         class="max-w-[100px] w-full h-auto mx-auto mb-2.5">

                    <p class="m-0">
                        <?php if(!is_null($item->salePrice) && $item->salePrice > 0): ?>
                            <span class="text-sw-orange text-lg font-bold">$<?php echo e(number_format($item->salePrice, 2)); ?></span>
                            <span class="line-through text-gray-400 text-sm ml-1">$<?php echo e(number_format($item->price, 2)); ?></span>
                        <?php else: ?>
                            <span class="text-lg font-bold text-gray-800">$<?php echo e(number_format($item->price, 2)); ?></span>
                        <?php endif; ?>
                    </p>

                    <p class="text-sm text-sw-product mt-1"><?php echo e($item->itemName); ?></p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>


<section class="pb-10">


<div class="container-960">
    <div class="pill-heading">
        <h2>Our brands and partnerships</h2>
    </div>
</div>


<div class="max-w-[960px] mx-auto md:pr-5 md:flex md:items-center">

        <div class="md:w-[300px] md:flex-shrink-0 px-5 py-4">
            <p class="text-base text-gray-800 m-0">
                These are some of our top brands and partnerships.<br>
                <a href="#" class="text-sw-blue font-semibold no-underline hover:underline">The best of the best is here.</a>
            </p>
        </div>

        <div class="bg-sw-dark md:flex-1 px-4 py-4 md:pl-10 md:pr-2.5 md:py-5 md:rounded-l-[50px]">
            <div class="grid grid-cols-3 md:flex md:justify-between gap-4 md:gap-5 items-center">
                <?php $__currentLoopData = [
                    ['file' => 'logo_nike.png',       'alt' => 'Nike'],
                    ['file' => 'logo_adidas.png',     'alt' => 'Adidas'],
                    ['file' => 'logo_skins.png',      'alt' => 'Skins'],
                    ['file' => 'logo_asics.png',      'alt' => 'Asics'],
                    ['file' => 'logo_newbalance.png', 'alt' => 'New Balance'],
                    ['file' => 'logo_wilson.png',     'alt' => 'Wilson'],
                ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e(asset('assets/' . $brand['file'])); ?>"
                         alt="<?php echo e($brand['alt']); ?> logo"
                         class="max-h-8 md:max-h-10 object-contain brightness-0 invert mx-auto md:mx-0">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\info\sports-warehouse\resources\views/home.blade.php ENDPATH**/ ?>