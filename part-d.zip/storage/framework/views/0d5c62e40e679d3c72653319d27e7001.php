

<?php $__env->startSection('title', 'Staff Login — Sports Warehouse'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-6 md:py-10">
    <div class="container-960">
        <div class="pill-heading mb-5"><h1>Staff Login</h1></div>

        <?php if($errors->any()): ?>
            <div class="alert-error">
                <ul class="list-disc list-inside m-0 p-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="contact-card max-w-[420px]">
            <form action="<?php echo e(route('login.attempt')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <fieldset class="contact-fieldset">
                    <legend class="contact-legend">Login</legend>
                    <div class="mb-4">
                        <label for="userName" class="contact-label">Username</label>
                        <input type="text" id="userName" name="userName" value="<?php echo e(old('userName')); ?>" required class="contact-input">
                    </div>
                    <div class="mb-4">
                        <label for="password" class="contact-label">Password</label>
                        <input type="password" id="password" name="password" required class="contact-input">
                    </div>
                    <button type="submit" class="contact-submit">Log in</button>
                </fieldset>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\info\sports-warehouse\resources\views/auth/login.blade.php ENDPATH**/ ?>