<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Sports Warehouse'); ?></title>

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap" rel="stylesheet">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="font-sans text-gray-800 bg-white">

    
    <header>

        
        <div class="bg-sw-blue text-white">
            <div class="container-960 py-3 flex justify-between items-center gap-4">
                <nav class="hidden md:flex items-center gap-4 text-sm">
                    <a href="<?php echo e(route('home')); ?>" class="hover:text-sw-orange whitespace-nowrap">Home</a>
                    <a href="#" class="hover:text-sw-orange whitespace-nowrap">About SW</a>
                    <a href="<?php echo e(route('contact.show')); ?>" class="hover:text-sw-orange whitespace-nowrap">Contact Us</a>
                    <a href="<?php echo e(route('products.index')); ?>" class="hover:text-sw-orange whitespace-nowrap">View Products</a>
                </nav>
                <div class="flex items-center gap-4 text-sm ml-auto">
                    <?php $cartCount = collect(session('cart', []))->sum('qty'); ?>
                    <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('admin.items.index')); ?>" class="hover:text-sw-orange whitespace-nowrap"><i class="fas fa-cog mr-1.5"></i> Manage</a>
                    <a href="<?php echo e(route('account.password')); ?>" class="hidden md:inline-flex items-center hover:text-sw-orange whitespace-nowrap">
                    <i class="fas fa-user mr-1.5"></i> <?php echo e(auth()->user()->userName); ?></a>
                    
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                     <?php echo csrf_field(); ?>
                    <button type="submit" class="hover:text-sw-orange whitespace-nowrap"><i class="fas fa-sign-out-alt mr-1.5"></i> Logout</button>
                    </form>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="hidden md:inline-flex items-center hover:text-sw-orange whitespace-nowrap">
                        <i class="fas fa-lock mr-1.5"></i> Login</a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('cart.index')); ?>" class="hover:text-sw-orange whitespace-nowrap">
                        <i class="fas fa-shopping-cart mr-1.5"></i> View Cart
                    </a>
                    <a href="<?php echo e(route('cart.index')); ?>" class="inline-block px-4 py-1 rounded-full bg-black/15 hover:bg-sw-orange whitespace-nowrap">
                        <?php echo e($cartCount); ?> <?php echo e($cartCount == 1 ? 'item' : 'items'); ?>

                    </a>
                </div>
            </div>
        </div>

        
        <div class="container-960 py-4">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-4">
                <a href="<?php echo e(route('home')); ?>" class="block">
                    <img src="<?php echo e(asset('assets/sports-warehouse-logo-600.png')); ?>"
                         alt="Sports Warehouse"
                         class="max-h-[60px] md:max-h-[83px] w-auto">
                </a>
                <form action="<?php echo e(route('search')); ?>" method="GET" role="search" class="flex items-center gap-2 w-full md:w-auto">
    <label for="site-search" class="sr-only">Search products</label>
    <input type="search" id="site-search" name="q" placeholder="Search products"
           value="<?php echo e(request('q')); ?>"
           class="w-full md:max-w-[220px] h-10 px-4 rounded-full border border-sw-grey bg-transparent text-sw-grey placeholder:text-sw-grey outline-none focus:outline-2 focus:outline-sw-orange">
                    <button type="submit" class="w-10 h-10 flex-shrink-0 bg-sw-dark text-white rounded-full flex items-center justify-center hover:bg-sw-orange">
                        <i class="fas fa-search"></i>
                    </button>
                </form>
            </div>

            
            <?php
                $navCategories = \App\Models\Category::orderBy('categoryId')->get();
            ?>
            <nav class="bg-sw-dark p-2.5 rounded-lg md:rounded-l-[40px] md:rounded-r-none md:p-0 md:py-2.5">
                <div class="grid grid-cols-2 gap-2 md:flex md:gap-0 md:pl-5">
                    <?php $__currentLoopData = $navCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('categories.show', $cat->slug)); ?>"
                           class="text-white text-sm font-normal text-center px-3 py-2 rounded-md md:rounded-full border md:border-0 border-sw-blue hover:bg-sw-blue">
                            <?php echo e($cat->categoryName); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </nav>
        </div>
    </header>

    
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <footer>
        <div class="bg-sw-blue text-white">
            <div class="container-960 py-6 flex flex-col md:flex-row md:justify-between md:items-stretch gap-6 md:gap-7">

                
                <div class="w-full md:max-w-[320px] md:flex-1">
                    <h3 class="text-lg font-normal mb-4">Site navigation</h3>
                    <ul class="footer-list">
                        <li><a href="<?php echo e(route('home')); ?>" class="hover:underline">Home</a></li>
                        <li><a href="#" class="hover:underline">About SW</a></li>
                        <li><a href="<?php echo e(route('contact.show')); ?>" class="hover:underline">Contact us</a></li>
                        <li><a href="<?php echo e(route('products.index')); ?>" class="hover:underline">View products</a></li>
                        <li><a href="#" class="hover:underline">Privacy policy</a></li>
                    </ul>
                </div>

                
                <?php
                    $footerCategories = \App\Models\Category::orderBy('categoryId')->get();
                ?>
                <div class="hidden md:block md:flex-1 md:max-w-[320px] bg-sw-orange px-5 py-6 md:-my-6">
                    <h3 class="text-lg font-normal mb-4">Product categories</h3>
                    <ul class="footer-list">
                        <?php $__currentLoopData = $footerCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('categories.show', $cat->slug)); ?>" class="hover:text-sw-blue"><?php echo e($cat->categoryName); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                
                <div class="w-full md:max-w-[320px] md:flex-1">
                    <h3 class="text-lg font-normal mb-4">Contact Sports Warehouse</h3>
                    <div class="flex justify-between gap-4">
                        <?php $__currentLoopData = [
                            ['icon' => 'fab fa-facebook-f', 'label' => 'Facebook'],
                            ['icon' => 'fab fa-instagram', 'label' => 'Instagram'],
                            ['icon' => 'fab fa-twitter',    'label' => 'Twitter'],
                            ['icon' => 'fas fa-paper-plane','label' => 'Email'],

                        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="#" class="flex flex-col items-center group">
                                <span class="text-3xl border border-white rounded-full w-[68px] h-[68px] flex items-center justify-center text-white group-hover:bg-sw-orange transition-colors">
                                    <i class="<?php echo e($social['icon']); ?>"></i>
                                </span>
                                <span class="mt-2 text-sm text-white group-hover:text-sw-orange transition-colors"><?php echo e($social['label']); ?></span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="bg-white text-sw-grey text-center text-xs px-4 py-2.5">
            &copy; Copyright <?php echo e(date('Y')); ?> Sports Warehouse. &nbsp; All rights reserved. &nbsp; Website made by Gelos Enterprises and Jessica Brown
        </div>
    </footer>

</body>
</html><?php /**PATH C:\Users\info\sports-warehouse\resources\views/layouts/app.blade.php ENDPATH**/ ?>