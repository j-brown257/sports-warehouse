

<?php $__env->startSection('title', 'Manage Products — Sports Warehouse'); ?>

<?php $__env->startSection('content'); ?>
<section class="py-6 md:py-10">
    <div class="container-960">
        
        <?php echo $__env->make('admin._nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="pill-heading mb-5"><h1>Products</h1></div>
        
        <?php if(session('success')): ?><div class="alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
        <?php if(session('error')): ?><div class="alert-error"><?php echo e(session('error')); ?></div><?php endif; ?>

        <div class="mb-4 flex gap-3">
            <a href="<?php echo e(route('admin.items.create')); ?>"
               class="inline-block px-5 py-2.5 bg-sw-blue text-white font-semibold rounded hover:bg-sw-teal transition-colors">+ New Product</a>   
        </div>
    
        <div class="bg-white border border-gray-300 rounded-lg overflow-hidden">
    <table class="w-full text-left">
        <thead class="hidden md:table-header-group">
            <tr class="border-b-2 border-gray-200 text-sw-grey text-sm">
                <th class="p-3">ID</th>
                <th class="p-3">Name</th>
                <th class="p-3">Category</th>
                <th class="p-3 text-right">Price</th>
                <th class="p-3">Featured</th>
                <th class="p-3 text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="block md:table-row border-b border-gray-200 md:border-gray-100 p-3 md:p-0">
                    <td class="block md:table-cell md:p-3 before:content-['ID:_'] before:font-semibold before:text-sw-grey md:before:content-none"><?php echo e($item->itemId); ?></td>
                    <td class="block md:table-cell md:p-3 before:content-['Name:_'] before:font-semibold before:text-sw-grey md:before:content-none"><?php echo e($item->itemName); ?></td>
                    <td class="block md:table-cell md:p-3 before:content-['Category:_'] before:font-semibold before:text-sw-grey md:before:content-none"><?php echo e($item->category->categoryName ?? '—'); ?></td>
                    <td class="block md:table-cell md:p-3 md:text-right before:content-['Price:_'] before:font-semibold before:text-sw-grey md:before:content-none">
                        <?php if(!is_null($item->salePrice) && $item->salePrice > 0): ?>
                            <span class="text-sw-orange font-semibold">$<?php echo e(number_format($item->salePrice, 2)); ?></span>
                        <?php else: ?>
                            $<?php echo e(number_format($item->price, 2)); ?>

                        <?php endif; ?>
                    </td>
                    <td class="block md:table-cell md:p-3 before:content-['Featured:_'] before:font-semibold before:text-sw-grey md:before:content-none"><?php echo e($item->featured ? 'Yes' : 'No'); ?></td>
                    <td class="block md:table-cell md:p-3 md:text-right whitespace-nowrap mt-2 md:mt-0">
                        <a href="<?php echo e(route('admin.items.edit', $item)); ?>" class="text-sw-blue hover:underline mr-4">Edit</a>
                        <form action="<?php echo e(route('admin.items.destroy', $item)); ?>" method="POST" class="inline" onsubmit="return confirm('Delete this product?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 hover:underline">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr class="block md:table-row"><td class="block md:table-cell p-3 text-sw-grey" colspan="6">No products yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\info\sports-warehouse\resources\views/admin/items/index.blade.php ENDPATH**/ ?>