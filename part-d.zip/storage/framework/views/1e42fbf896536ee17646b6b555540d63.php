

<?php $__env->startSection('title', 'Contact Us — Sports Warehouse'); ?>

<?php $__env->startSection('content'); ?>

<section class="py-6 md:py-10">
    <div class="container-960">

        
        <div class="pill-heading">
            <h1>Contact Us</h1>
        </div>

        
        <div class="contact-card">

            <p class="text-base text-sw-grey mb-6 leading-relaxed">
                Sports Warehouse is coming soon. If you have any questions, we would love to hear from you. Please complete the form below.
            </p>

            
            <?php if(session('success')): ?>
                <div class="alert-success" aria-live="polite">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            
            <?php if($errors->any()): ?>
                <div class="alert-error" aria-live="polite">
                    <ul class="list-disc list-inside m-0 p-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('contact.submit')); ?>" method="POST" novalidate>
                <?php echo csrf_field(); ?>

                <fieldset class="contact-fieldset">
                    <legend class="contact-legend">Your details</legend>

                    <div class="mb-4">
                        <label for="firstName" class="contact-label">First name</label>
                        <input type="text" id="firstName" name="firstName" value="<?php echo e(old('firstName')); ?>" required class="contact-input">
                    </div>

                    <div class="mb-4">
                        <label for="lastName" class="contact-label">Last name</label>
                        <input type="text" id="lastName" name="lastName" value="<?php echo e(old('lastName')); ?>" required class="contact-input">
                    </div>

                    <div class="mb-4">
                        <label for="contactNumber" class="contact-label">Contact number</label>
                        <input type="text" id="contactNumber" name="contactNumber" value="<?php echo e(old('contactNumber')); ?>" class="contact-input">
                    </div>

                    <div class="mb-4">
                        <label for="email" class="contact-label">Email address</label>
                        <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required class="contact-input">
                    </div>

                    <div class="mb-4">
                        <label for="question" class="contact-label">Question</label>
                        <textarea id="question" name="question" rows="5" class="contact-input resize-y min-h-[140px]"><?php echo e(old('question')); ?></textarea>
                    </div>

                    <div class="mb-4 flex items-start gap-2.5">
                        <input type="checkbox" id="terms" name="terms" value="yes" required <?php if(old('terms') === 'yes'): echo 'checked'; endif; ?> class="mt-1 flex-shrink-0">
                        <label for="terms" class="m-0 text-base text-sw-grey">
                            I agree to the <a href="#" class="text-sw-teal hover:text-sw-orange hover:underline">terms and conditions</a>
                        </label>
                    </div>

                    <div class="mt-6">
                        <button type="submit" class="contact-submit">Submit</button>
                    </div>
                </fieldset>
            </form>

        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\info\sports-warehouse\resources\views/contact.blade.php ENDPATH**/ ?>